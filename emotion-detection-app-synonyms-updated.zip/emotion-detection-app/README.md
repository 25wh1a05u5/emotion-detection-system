# MoodBloom — Emotion Detection and Mood Tracker

A beginner-friendly Software Engineering lab project built with Node.js, Express, HTML, CSS and browser JavaScript.

## Run in Visual Studio Code
1. Install Node.js 18 or newer from https://nodejs.org.
2. Open this project folder in VS Code (the folder that contains `package.json`).
3. Open **Terminal → New Terminal**.
4. Run `npm install`.
5. Run `npm test` to execute the automated tests.
6. Run `node app.js` to start the website.
7. Open http://localhost:3000 in Chrome or Edge.
8. Press Ctrl+C in the terminal to stop the server.

## Features
- Pastel mood dashboard and emotion analysis interface.
- Text emotion estimates using an explainable synonym lexicon and scenario rules.
- Browser speech-to-text with automatic analysis when speaking ends (Chrome/Edge recommended).
- Supportive suggestions based on the estimated emotion.
- JSON-file mood history, filtering, deletion, weekly summary, and insights.
- Demo data and Node.js automated tests.

## Important limitations
The analyser uses rules and keywords; it is not a trained AI model and can misread sarcasm, mixed feelings, negation, and complex situations. Voice input analyses the words recognised by the browser, not the emotional tone of the voice. Results are estimates, not diagnoses or medical advice. Speech recognition requires microphone permission and browser support.

## Project structure
- `app.js`: Express server and middleware.
- `routes/`: API endpoints for emotion analysis and mood records.
- `src/emotionAnalyzer.js`: emotion rules, synonyms, and scenario clues.
- `src/moodService.js`: mood record storage and summary logic.
- `public/`: HTML, CSS, and browser JavaScript.
- `data/moods.json`: saved mood history.
- `tests/`: automated tests using Node's built-in test runner.
