// Entry point: creates the Express app, wires routes, serves the frontend.
const express = require('express');
const path = require('path');
const app = express();

app.use(express.json({ limit: '100kb' }));                 // parse JSON bodies
app.use(express.static(path.join(__dirname, 'public')));   // serve frontend
app.use('/api/emotion', require('./routes/emotionRoutes'));
app.use('/api/moods', require('./routes/moodRoutes'));
app.use('/api', (req, res) => res.status(404).json({ error: 'API route not found' }));

// Central error handler: every error becomes a JSON response
app.use((err, req, res, next) => {
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Invalid JSON body' });
  const status = err.status || 500;
  if (status === 500) console.error(err);
  res.status(status).json({ error: status === 500 ? 'Internal server error' : err.message });
});

const PORT = process.env.PORT || 3000;
if (require.main === module) {
  app.listen(PORT, () => console.log(`Emotion Tracker running at http://localhost:${PORT}`));
}
module.exports = app; // exported so tests can start it on a random port
