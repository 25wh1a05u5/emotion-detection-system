// Frontend logic: navigation, analysis, history, dashboard and pure-CSS charts (no external libraries).
const $ = id => document.getElementById(id);
const EMOTIONS = ['Happy', 'Sad', 'Angry', 'Anxious', 'Calm', 'Excited', 'Neutral'];
const META = { Happy: ['😊', '#fbe3a1'], Sad: ['😢', '#c3d6f3'], Angry: ['😠', '#f6bcbc'], Anxious: ['😰', '#dcc6f1'], Calm: ['😌', '#bfe6df'], Excited: ['🤩', '#fbc7dc'], Neutral: ['😐', '#e1dde9'] };
const TIPS = {
  Happy: ['Record this positive moment in a journal.', 'Share something kind with someone today.'],
  Sad: ['Try a few minutes of journaling.', 'Take a gentle break.', 'Consider talking to someone you trust.'],
  Angry: ['Pause before responding.', 'Take 5 slow breaths.', 'Give yourself some time before replying.'],
  Anxious: ['Try 5-4-3-2-1 grounding: notice 5 things you see, 4 you can touch, 3 you hear...', 'Breathe gently in for 4, out for 6.', 'Break the task into smaller steps.'],
  Calm: ['Keep up your relaxing routine.', 'Notice what helped you feel this way.'],
  Excited: ['Write your ideas down.', 'Choose one small next step.'],
  Neutral: ['Check in with yourself: what do you need right now?', 'Take a short break.']
};
let current = null, usedVoice = false, manual = '', allMoods = [];
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const badge = e => `<span class="badge" style="background:${META[e][1]}">${META[e][0]} ${e}</span>`;

function banner(msg) { $('banner').textContent = msg; $('banner').classList.toggle('hidden', !msg); }
async function api(url, opt = {}) {
  let r;
  try { r = await fetch(url, { headers: { 'Content-Type': 'application/json' }, ...opt }); }
  catch (e) { throw new Error('Cannot reach the server. Run "node app.js" and open http://localhost:3000'); }
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || 'Request failed');
  return d;
}
if (location.protocol === 'file:') banner('⚠️ You opened this file directly. Run "node app.js" in the VS Code terminal, then open http://localhost:3000 in Chrome.');

function show(view) {
  document.querySelectorAll('.view').forEach(v => v.classList.add('hidden'));
  $('view-' + view).classList.remove('hidden');
  document.querySelectorAll('.nav').forEach(n => n.classList.toggle('active', n.dataset.view === view));
  refresh();
}
document.querySelectorAll('.nav').forEach(n => n.addEventListener('click', () => show(n.dataset.view)));
$('newBtn').addEventListener('click', () => show('analyse'));

// ----- Mood chips and filter options -----
EMOTIONS.forEach(e => {
  const b = document.createElement('button');
  b.type = 'button'; b.className = 'chip'; b.dataset.mood = e; b.style.background = META[e][1]; b.textContent = META[e][0] + ' ' + e;
  b.addEventListener('click', () => { manual = manual === e ? '' : e; document.querySelectorAll('.chip').forEach(c => c.classList.toggle('sel', c.dataset.mood === manual)); });
  $('chips').appendChild(b);
  $('fEmotion').add(new Option(e, e));
});

// ----- Analyse -----
$('textInput').addEventListener('input', () => { usedVoice = false; });
async function runAnalysis(textOverride = null, methodOverride = null) {
  $('errorMsg').textContent = ''; $('saveMsg').textContent = '';
  const text = (textOverride !== null ? textOverride : $('textInput').value).trim();
  try {
    if (text) {
      const r = await api('/api/emotion/analyze', { method: 'POST', body: JSON.stringify({ text }) });
      current = { emotion: r.emotion, method: methodOverride || (usedVoice ? 'voice' : 'text'), text, explanation: r.explanation, share: r.matchShare };
    } else if (manual) {
      current = { emotion: manual, method: 'manual', text: '', explanation: 'You selected this mood manually.', share: null };
    } else { $('errorMsg').textContent = 'Please type something, speak, or pick a mood.'; return; }
    renderResult();
    $('saveBox').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  } catch (e) { $('errorMsg').textContent = e.message; }
}
$('analyseBtn').addEventListener('click', () => runAnalysis());
function renderResult() {
  const c = current;
  $('resultBox').className = 'res';
  $('resultBox').innerHTML = `<div class="ico">${META[c.emotion][0]}</div><h2>${c.emotion}</h2><p>${esc(c.explanation)}</p>` +
    (c.share !== null ? `<p class="note">Rule-signal share: ${c.share}% (not a probability or clinical confidence)</p>` : '') +
    `<h4>Supportive suggestions</h4><ul>${TIPS[c.emotion].map(t => `<li>${esc(t)}</li>`).join('')}</ul><p class="note">General wellbeing tips only — not medical advice.</p>`;
  $('saveBox').classList.remove('hidden');
}
$('saveBtn').addEventListener('click', async () => {
  if (!current) return;
  try {
    await api('/api/moods', { method: 'POST', body: JSON.stringify({ emotion: current.emotion, method: current.method, text: current.text, note: $('noteInput').value }) });
    $('saveMsg').textContent = 'Saved to history ✔'; $('noteInput').value = ''; refresh();
  } catch (e) { $('errorMsg').textContent = e.message; }
});

// ----- Voice (Web Speech API): automatically analyse when the user finishes speaking -----
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
let recognition = null;
let voiceTranscript = '';
$('micBtn').addEventListener('click', () => {
  if (!SR) { $('voiceMsg').textContent = 'Speech recognition is not supported in this browser. Please type instead (Chrome or Edge works best).'; return; }
  if (recognition) { recognition.stop(); return; }
  recognition = new SR();
  recognition.lang = 'en-US';
  recognition.continuous = false;
  recognition.interimResults = false;
  voiceTranscript = '';
  $('micBtn').textContent = '⏹ Stop speaking';
  $('voiceMsg').textContent = '🎙️ Listening... Speak naturally. Your words will be analysed automatically when you finish.';
  $('errorMsg').textContent = '';
  recognition.onresult = ev => {
    voiceTranscript = Array.from(ev.results).map(result => result[0].transcript).join(' ').trim();
    $('textInput').value = voiceTranscript;
    usedVoice = true;
    $('voiceMsg').textContent = 'Heard: “' + voiceTranscript + '” — analysing automatically…';
  };
  recognition.onerror = ev => {
    $('voiceMsg').textContent = 'Could not use the microphone (' + ev.error + '). Check microphone permission or type instead.';
  };
  recognition.onend = async () => {
    recognition = null;
    $('micBtn').textContent = '🎤 Speak';
    if (voiceTranscript) {
      usedVoice = true;
      $('voiceMsg').textContent = 'Voice captured. Analysing your words now…';
      await runAnalysis(voiceTranscript, 'voice');
      if (current && current.method === 'voice') $('voiceMsg').textContent = 'Analysis complete! Your speech was converted to text; the app analyses the words, not vocal tone.';
    } else if (!$('errorMsg').textContent) {
      $('voiceMsg').textContent = 'No speech was detected. Please try again or type your text.';
    }
  };
  try { recognition.start(); }
  catch (e) { recognition = null; $('micBtn').textContent = '🎤 Speak'; $('voiceMsg').textContent = 'Could not start microphone. Please check browser permissions and try again.'; }
});

// ----- Data and rendering -----
async function refresh() {
  try {
    allMoods = await api('/api/moods');
    const s = await api('/api/moods/summary');
    banner(location.protocol === 'file:' ? $('banner').textContent : '');
    renderDashboard(s); renderInsights(s); await renderHistory();
  } catch (e) { banner('⚠️ ' + e.message); }
}
function renderDashboard(s) {
  $('statTotal').textContent = allMoods.length;
  const counts = {}; allMoods.forEach(m => (counts[m.emotion] = (counts[m.emotion] || 0) + 1));
  const top = Object.keys(counts).sort((a, b) => counts[b] - counts[a])[0];
  $('statTop').innerHTML = top ? badge(top) : '—';
  $('statLatest').innerHTML = allMoods[0] ? badge(allMoods[0].emotion) : '—';
  $('recentList').innerHTML = allMoods.slice(0, 5).map(m => `<div class="recent">${badge(m.emotion)}<small>${m.date} ${m.time}</small></div>`).join('') || '<div class="empty">🌱 No entries yet.</div>';
  const max = Math.max(1, ...s.days.map(d => d.count));
  $('weekBars').innerHTML = s.days.map(d => `<div class="col">${d.count}<b style="height:${Math.max(4, (d.count / max) * 130)}px"></b>${d.date.slice(5)}</div>`).join('');
}
function renderInsights(s) {
  const total = allMoods.length, counts = {};
  EMOTIONS.forEach(e => (counts[e] = allMoods.filter(m => m.emotion === e).length));
  let start = 0; const parts = [];
  EMOTIONS.forEach(e => { if (!counts[e]) return; const end = start + (counts[e] / total) * 100; parts.push(`${META[e][1]} ${start}% ${end}%`); start = end; });
  $('donut').style.background = total ? `conic-gradient(${parts.join(',')})` : '#ece6fa';
  $('donutTotal').textContent = total ? total + ' entries' : 'No data';
  $('legend').innerHTML = EMOTIONS.map(e => `<div class="lg"><i style="background:${META[e][1]}"></i>${META[e][0]} ${e}: ${counts[e]}</div>`).join('');
  $('weekSummary').innerHTML = s.total === 0 ? '<div class="empty">No entries in the last 7 days.</div>' :
    `<p>${s.total} entr${s.total === 1 ? 'y' : 'ies'} in the last 7 days.</p>` + EMOTIONS.map(e => `<div class="sumrow">${badge(e)} ${s.counts[e]}<div class="bar"><i style="width:${(s.counts[e] / s.total) * 100}%;background:${META[e][1]}"></i></div></div>`).join('');
}
async function renderHistory() {
  const q = new URLSearchParams();
  if ($('fEmotion').value) q.set('emotion', $('fEmotion').value);
  if ($('fFrom').value) q.set('from', $('fFrom').value);
  if ($('fTo').value) q.set('to', $('fTo').value);
  const rows = await api('/api/moods?' + q);
  $('historyEmpty').classList.toggle('hidden', rows.length > 0);
  $('historyBody').innerHTML = rows.map(m => `<tr><td>${m.date}</td><td>${m.time}</td><td>${esc(m.method)}</td><td>${badge(m.emotion)}</td><td>${esc(m.note)}</td><td><button class="btn ghost" data-del="${esc(m.id)}">Delete</button></td></tr>`).join('');
}
['fEmotion', 'fFrom', 'fTo'].forEach(id => $(id).addEventListener('change', () => renderHistory().catch(e => banner('⚠️ ' + e.message))));
$('fReset').addEventListener('click', () => { $('fEmotion').value = ''; $('fFrom').value = ''; $('fTo').value = ''; renderHistory(); });
$('historyBody').addEventListener('click', async ev => {
  const id = ev.target.dataset.del; if (!id) return;
  try { await api('/api/moods/' + id, { method: 'DELETE' }); refresh(); } catch (e) { alert(e.message); }
});
$('clearBtn').addEventListener('click', async () => {
  if (!confirm('Delete ALL mood history? This cannot be undone.')) return;
  try { await api('/api/moods', { method: 'DELETE' }); refresh(); } catch (e) { alert(e.message); }
});
$('demoBtn').addEventListener('click', async () => { try { await api('/api/moods/demo', { method: 'POST' }); refresh(); } catch (e) { alert(e.message); } });
refresh();
