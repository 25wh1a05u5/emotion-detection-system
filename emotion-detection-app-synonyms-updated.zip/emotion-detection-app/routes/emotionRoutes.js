const express = require('express');
const { analyze } = require('../src/emotionAnalyzer');
const router = express.Router();
// POST /api/emotion/analyze  body: { "text": "..." }
router.post('/analyze', (req, res, next) => {
  try { res.json(analyze(req.body && req.body.text)); } catch (e) { next(e); }
});
module.exports = router;
