const express = require('express');
const svc = require('../src/moodService');
const router = express.Router();
// GET /api/moods?emotion=&from=&to=
router.get('/', (req, res, next) => { try { res.json(svc.list(req.query)); } catch (e) { next(e); } });
router.get('/summary', (req, res, next) => { try { res.json(svc.weeklySummary()); } catch (e) { next(e); } });
router.post('/', (req, res, next) => { try { res.status(201).json(svc.add(req.body || {})); } catch (e) { next(e); } });
router.post('/demo', (req, res, next) => { try { res.status(201).json({ added: svc.loadDemo() }); } catch (e) { next(e); } });
router.delete('/:id', (req, res, next) => {
  try { if (!svc.remove(req.params.id)) return res.status(404).json({ error: 'Entry not found' }); res.json({ deleted: true }); }
  catch (e) { next(e); }
});
router.delete('/', (req, res, next) => { try { svc.clear(); res.json({ cleared: true }); } catch (e) { next(e); } });
module.exports = router;
