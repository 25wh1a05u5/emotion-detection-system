// Explainable rule-based emotion analyser using synonyms, simple negation,
// and scenario clues. This is a heuristic, not a trained AI or diagnosis.
const EMOTIONS = ['Happy', 'Sad', 'Angry', 'Anxious', 'Calm', 'Excited', 'Neutral'];
const MAX_LENGTH = 1000;

const LEXICON = {
  Happy: `happy happiness glad joyful joy joyous cheerful delighted pleased pleasedness content contented satisfied grateful thankful appreciative blessed lucky fortunate wonderful great good nice lovely fantastic excellent amazing awesome positive upbeat cheerful merry jolly smiling smile laughed laughing laughter amused pleased proud optimistic hopeful fulfilled accomplished successful thriving vibrant delighted overjoyed elated ecstatic blissful cheerful beaming radiant pleased excited enjoyable enjoyed fun playful funny love loved loving adore adored appreciated welcomed included accepted relieved sunny cheerful`.split(/\s+/),
  Sad: `sad sadness unhappy miserable gloomy glum down blue low tearful crying cried cry weeping sobbing sorrow sorrowful grief grieving mournful heartbroken broken devastated depressed lonely alone isolated rejected abandoned unwanted disappointed disappointing discouraged disheartened hopeless helpless empty numb regret regretful miss missing loss lost upset hurt hurting painful pain distressed miserable dull gloomy pessimistic defeated exhausted drained tired weary miserable crushed unhappy dissatisfied homesick melancholy forlorn`.split(/\s+/),
  Angry: `angry anger mad furious annoyed irritating irritated frustration frustrated rage raging outraged resent resentful bitter offended infuriated enraged furious hostile aggressive hateful hate hated despise loathe irritated annoyed cross livid fuming furious pissed injustice unfair disrespect disrespectful insult insulted betrayed betrayal provoked aggravated exasperated fed temper irritated infuriated indignant`.split(/\s+/),
  Anxious: `anxious anxiety worried worry worrying nervous nerves scared afraid fear fearful frightened terrified panicked panic stressed stress stressful overwhelmed uneasy tense tension restless uncertain insecure apprehensive jittery concerned concern doubtful hesitant pressured pressured overwhelmed intimidated intimidated uneasy troubled apprehensive alarmed frightened paranoid agitated unsettled uncomfortable insecure shaky trembling sweating overthinking dread dreadful apprehension uneasy`.split(/\s+/),
  Calm: `calm calmly peaceful peace peacefully peacefulness serene serenity relaxed relaxation restful restful rested quiet quietly tranquil tranquility composed composedness at ease ease comfortable comfort safe secure steady balanced balancedness relieved relief mindful mindfulness refreshed soothing grounded centered centred mellow chill chilled laidback settled settledness patient patientness untroubled harmonious harmony still stillness placid collected unworried carefree contentment meditative soothing gentle soft unwound relaxedness`.split(/\s+/),
  Excited: `excited excitement thrilled thrilled eager eagerness pumped amazing energetic energy enthusiastic enthusiasm ecstatic exhilarated exhilaration adventurous adventure celebrate celebration celebrating anticipating anticipation looking forward thrilled hyped psyched eager keen animated passionate inspired motivated electrified buzzing delighted can't wait cannot wait pumped joyful`.split(/\s+/)
};

// Scenario patterns help when a person describes an event without naming the emotion.
const SCENARIOS = [
  { emotion: 'Anxious', weight: 3, patterns: [
    /\b(exam|test|interview|presentation|deadline)\b.{0,45}\b(tomorrow|today|soon|coming|approaching|next week)\b/i,
    /\b(worried|scared|nervous|uneasy|concerned)\b.{0,35}\b(about|for)\b/i,
    /\b(can't|cannot)\s+(sleep|stop thinking|focus)\b/i,
    /\b(too much|a lot of) pressure\b/i,
    /\b(what if|afraid that|fear of failing)\b/i
  ]},
  { emotion: 'Sad', weight: 3, patterns: [
    /\b(broke up|breakup|relationship ended|lost someone|miss them|left out)\b/i,
    /\b(failed|didn't pass|did not pass)\b.{0,35}\b(exam|test|course|subject)\b/i,
    /\b(no one|nobody)\s+(cares|understands|talks to me)\b/i
  ]},
  { emotion: 'Angry', weight: 3, patterns: [
    /\b(that's|that is|it is|it's)\s+(so\s+)?(unfair|rude|disrespectful)\b/i,
    /\b(someone|they|he|she)\b.{0,35}\b(lied|cheated|betrayed|insulted)\b/i,
    /\b(keep|keeps|kept) interrupting me\b/i,
    /\b(fed up with|tired of being treated)\b/i
  ]},
  { emotion: 'Happy', weight: 3, patterns: [
    /\b(got|received|earned|won)\b.{0,40}\b(job|award|prize|promotion|good grade|good news)\b/i,
    /\b(spent|spending) time with\b.{0,30}\b(friends|family|people i love)\b/i,
    /\bmy hard work\s+(paid off|worked)\b/i,
    /\b(proud of myself|achieved my goal|made my family proud)\b/i
  ]},
  { emotion: 'Excited', weight: 3, patterns: [
    /\b(can't wait|cannot wait|looking forward to)\b/i,
    /\b(going on|planning)\s+(a\s+)?(trip|vacation|holiday|concert)\b/i,
    /\b(first day|new beginning|big opportunity)\b/i,
    /\b(got accepted|got selected|dream came true)\b/i
  ]},
  { emotion: 'Calm', weight: 3, patterns: [
    /\b(after|while)\s+(meditating|meditation|yoga|a walk|deep breathing)\b/i,
    /\b(feel|feeling|felt|was|is|so)\s+(safe|at peace|at ease|grounded|relaxed|peaceful|peace|calm|tranquil|serene)\b/i,
    /\b(no rush|everything is under control|mind is quiet|feel at rest)\b/i,
    /\b(peaceful|calm|relaxing|relaxed)\b.{0,35}\b(school|home|class|place|day|environment)\b/i,
    /\b(school|home|class|place|day|environment)\b.{0,35}\b(peaceful|calm|relaxing|relaxed|peace)\b/i
  ]}
];

const NEGATIONS = new Set(['not', 'never', 'no', "isn't", "don't", "didn't", "wasn't", 'hardly', 'without', 'cannot']);

function analyze(text) {
  if (typeof text !== 'string' || text.trim() === '') {
    const error = new Error('Please enter some text to analyse.');
    error.status = 400;
    throw error;
  }
  if (text.length > MAX_LENGTH) {
    const error = new Error(`Text must be at most ${MAX_LENGTH} characters.`);
    error.status = 400;
    throw error;
  }

  const tokens = text.toLowerCase().match(/[a-z']+/g) || [];
  const scores = Object.fromEntries(EMOTIONS.map(emotion => [emotion, 0]));
  const matchedWords = [];
  const negatedWords = [];

  tokens.forEach((word, index) => {
    for (const emotion of Object.keys(LEXICON)) {
      if (!LEXICON[emotion].includes(word)) continue;
      const previousWords = tokens.slice(Math.max(0, index - 3), index);
      if (previousWords.some(previous => NEGATIONS.has(previous))) {
        negatedWords.push(word);
        continue;
      }
      scores[emotion] += 1;
      matchedWords.push(word);
    }
  });

  const scenarioMatches = [];
  for (const scenario of SCENARIOS) {
    if (scenario.patterns.some(pattern => pattern.test(text))) {
      scores[scenario.emotion] += scenario.weight;
      scenarioMatches.push(scenario.emotion);
    }
  }

  const total = Object.values(scores).reduce((sum, score) => sum + score, 0);
  let emotion = 'Neutral';
  if (total > 0) {
    emotion = Object.keys(LEXICON).reduce((best, candidate) =>
      scores[candidate] > scores[best] ? candidate : best
    );
  }

  const matchShare = total > 0 ? Math.round((scores[emotion] / total) * 100) : null;
  const clues = [];
  if (matchedWords.length) clues.push(`emotion-related words: ${[...new Set(matchedWords)].join(', ')}`);
  if (scenarioMatches.length) clues.push(`scenario clues: ${[...new Set(scenarioMatches)].join(', ')}`);

  let explanation = total === 0
    ? 'No clear emotion clues were found. The result is Neutral; adding more context may help.'
    : `Estimated ${emotion} from ${clues.join(' and ')}. Context can be ambiguous, so treat this as a suggestion, not a fact.`;
  if (negatedWords.length) {
    explanation += ` Negated words were ignored where possible: ${[...new Set(negatedWords)].join(', ')}.`;
  }

  return {
    emotion,
    matchedWords: [...new Set(matchedWords)],
    scores,
    matchShare,
    method: 'lexicon-and-scenario-rules',
    explanation,
    scenarioMatches: [...new Set(scenarioMatches)]
  };
}

module.exports = { analyze, EMOTIONS, MAX_LENGTH };
