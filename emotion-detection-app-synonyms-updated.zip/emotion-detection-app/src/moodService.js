// Data layer: stores mood entries in data/moods.json (path can be overridden with MOOD_FILE).
const fs = require('fs');
const path = require('path');
const { EMOTIONS } = require('./emotionAnalyzer');
const METHODS = ['text', 'voice', 'manual'];

const filePath = () => process.env.MOOD_FILE || path.join(__dirname, '..', 'data', 'moods.json');
const bad = msg => { const e = new Error(msg); e.status = 400; return e; };
const pad = n => String(n).padStart(2, '0');
const localDate = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

function readAll() {
  try { const t = fs.readFileSync(filePath(), 'utf8'); return t.trim() ? JSON.parse(t) : []; }
  catch (e) { if (e.code === 'ENOENT') return []; throw e; }
}
function writeAll(list) {
  fs.mkdirSync(path.dirname(filePath()), { recursive: true });
  fs.writeFileSync(filePath(), JSON.stringify(list, null, 2));
}
function makeEntry({ emotion, method, text = '', note = '' }, when = new Date()) {
  if (!EMOTIONS.includes(emotion)) throw bad('Invalid emotion.');
  if (!METHODS.includes(method)) throw bad('Invalid input method.');
  if (String(note).length > 300) throw bad('Note must be at most 300 characters.');
  return {
    id: Date.now().toString(36) + Math.random().toString(36).slice(2, 7),
    emotion, method, text: String(text).slice(0, 1000), note: String(note),
    createdAt: when.toISOString(), date: localDate(when),
    time: `${pad(when.getHours())}:${pad(when.getMinutes())}`
  };
}
function add(data) { const list = readAll(); const e = makeEntry(data); list.push(e); writeAll(list); return e; }
function list({ emotion, from, to } = {}) {
  return readAll().filter(e => (!emotion || e.emotion === emotion) && (!from || e.date >= from) && (!to || e.date <= to))
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}
function remove(id) { const l = readAll(); const n = l.filter(e => e.id !== id); writeAll(n); return n.length !== l.length; }
function clear() { writeAll([]); }
function weeklySummary(now = new Date()) {
  const days = []; for (let i = 6; i >= 0; i--) days.push(localDate(new Date(now.getFullYear(), now.getMonth(), now.getDate() - i)));
  const week = readAll().filter(e => days.includes(e.date));
  const counts = {}; EMOTIONS.forEach(x => (counts[x] = 0));
  week.forEach(e => counts[e.emotion]++);
  return { total: week.length, counts, days: days.map(d => ({ date: d, count: week.filter(e => e.date === d).length })) };
}
function loadDemo() { // 14 sample entries spread over the last 7 days
  const sample = ['Happy', 'Calm', 'Anxious', 'Excited', 'Sad', 'Happy', 'Neutral', 'Angry', 'Calm', 'Happy', 'Anxious', 'Excited', 'Calm', 'Happy'];
  const l = readAll(); const now = new Date();
  sample.forEach((emotion, i) => {
    const when = new Date(now.getFullYear(), now.getMonth(), now.getDate() - (i % 7), 9 + (i % 10), 15);
    l.push(makeEntry({ emotion, method: i % 3 === 0 ? 'voice' : i % 3 === 1 ? 'text' : 'manual', text: 'Demo entry', note: 'Sample data' }, when));
  });
  writeAll(l); return sample.length;
}
module.exports = { add, list, remove, clear, weeklySummary, loadDemo };
