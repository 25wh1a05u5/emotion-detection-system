const test = require('node:test');
const assert = require('node:assert');
const os = require('os'), path = require('path'), fs = require('fs');
process.env.MOOD_FILE = path.join(os.tmpdir(), `moods-test-${process.pid}.json`); // never touch real data
const app = require('../app');
let server, base;
test.before(() => new Promise(r => { server = app.listen(0, () => { base = `http://127.0.0.1:${server.address().port}`; r(); }); }));
test.after(() => { server.close(); fs.rmSync(process.env.MOOD_FILE, { force: true }); });
const call = async (method, url, body) => {
  const r = await fetch(base + url, { method, headers: { 'Content-Type': 'application/json' }, body: body === undefined ? undefined : (typeof body === 'string' ? body : JSON.stringify(body)) });
  return { status: r.status, data: await r.json() };
};

test('POST analyze: empty text -> 400', async () => assert.strictEqual((await call('POST', '/api/emotion/analyze', { text: '' })).status, 400));
test('POST analyze: valid text -> Sad', async () => {
  const r = await call('POST', '/api/emotion/analyze', { text: 'I feel sad and lonely' });
  assert.strictEqual(r.status, 200); assert.strictEqual(r.data.emotion, 'Sad');
});
test('POST analyze: malformed JSON -> 400', async () => assert.strictEqual((await call('POST', '/api/emotion/analyze', '{bad')).status, 400));
test('unknown API route -> 404', async () => assert.strictEqual((await call('GET', '/api/nope')).status, 404));
test('POST moods: invalid emotion -> 400', async () => assert.strictEqual((await call('POST', '/api/moods', { emotion: 'Bored', method: 'text' })).status, 400));
test('save, list, filter, delete flow', async () => {
  const a = await call('POST', '/api/moods', { emotion: 'Happy', method: 'text', text: 'hi' });
  await call('POST', '/api/moods', { emotion: 'Sad', method: 'manual' });
  assert.strictEqual(a.status, 201);
  assert.strictEqual((await call('GET', '/api/moods')).data.length, 2);
  assert.strictEqual((await call('GET', '/api/moods?emotion=Sad')).data.length, 1);
  assert.strictEqual((await call('DELETE', '/api/moods/' + a.data.id)).status, 200);
  assert.strictEqual((await call('DELETE', '/api/moods/' + a.data.id)).status, 404);
});
test('weekly summary counts today\'s entries', async () => {
  const s = (await call('GET', '/api/moods/summary')).data;
  assert.strictEqual(s.total, 1); assert.strictEqual(s.counts.Sad, 1); assert.strictEqual(s.days.length, 7);
});
test('clear history', async () => {
  await call('DELETE', '/api/moods');
  assert.strictEqual((await call('GET', '/api/moods')).data.length, 0);
});
