const test = require('node:test');
const assert = require('node:assert');
const { analyze, MAX_LENGTH } = require('../src/emotionAnalyzer');

test('valid text: detects Happy', () => assert.strictEqual(analyze('I feel happy and grateful today').emotion, 'Happy'));
test('valid text: detects Anxious', () => assert.strictEqual(analyze('I am so worried and nervous').emotion, 'Anxious'));
test('no keywords gives Neutral', () => assert.strictEqual(analyze('I went to the shop').emotion, 'Neutral'));
test('negation is ignored', () => assert.strictEqual(analyze('I am not happy').emotion, 'Neutral'));
test('negative: empty text throws', () => assert.throws(() => analyze('   '), /enter some text/));
test('negative: non-string throws', () => assert.throws(() => analyze(42)));
test('boundary: max length ok, +1 rejected', () => {
  assert.doesNotThrow(() => analyze('a'.repeat(MAX_LENGTH)));
  assert.throws(() => analyze('a'.repeat(MAX_LENGTH + 1)));
});

test('synonym: detects Anxious from uneasy', () => assert.strictEqual(analyze('I feel uneasy about everything today').emotion, 'Anxious'));
test('scenario: exam tomorrow suggests Anxious', () => assert.strictEqual(analyze('My exam is tomorrow and I keep thinking about it').emotion, 'Anxious'));
test('scenario: hard work paid off suggests Happy', () => assert.strictEqual(analyze('My hard work paid off').emotion, 'Happy'));
